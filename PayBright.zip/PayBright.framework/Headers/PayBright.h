//
//  PayBright.h
//  PayBright
//
//  Created by Manpreet Singh on 15/08/18.
//  Copyright © 2018 Manpreet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CommonCrypto/CommonCrypto.h>

//! Project version number for PayBright.
FOUNDATION_EXPORT double PayBrightVersionNumber;

//! Project version string for PayBright.
FOUNDATION_EXPORT const unsigned char PayBrightVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PayBright/PublicHeader.h>

